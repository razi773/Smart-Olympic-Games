#ifndef NOTIFICATION_H
#define NOTIFICATION_H


#include <QSystemTrayIcon>
#include<QString>
class Notification
{
public:
    Notification();
    void notification_ajoutemploye();

    void notification_supprimeremploye();

    void notification_modifieremploye();



};



#endif // NOTIFICATION_H
